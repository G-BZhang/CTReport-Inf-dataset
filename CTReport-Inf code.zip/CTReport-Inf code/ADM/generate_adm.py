import os
import numpy as np
import torch
from PIL import Image
from torchvision import transforms
from gradcam_utils import GradCAM, show_cam_on_image       # 自定义 Grad-CAM 可视化工具
from model import resnet34
import pickle
import cv2
import glob
import tqdm

#os.environ["CUDA_VISIBLE_DEVICES"] = "2"
#加载阈值配置文件
if os.path.exists(r"E:\zb\EKAGen-main\datasets\thresholds.pkl"):
    with open(r"E:\zb\EKAGen-main\datasets\thresholds.pkl", "rb") as f:
        thresholds = pickle.load(f)

#初始化模型函数
def get_model():
    #model = resnet34(num_classes=14).cuda()
    model = resnet34(num_classes=14).to('cuda:0')
    model_weight_path = "./weights/best_weight.pth"
    model.load_state_dict(torch.load(model_weight_path, map_location="cpu"))
    return model.eval()

#主处理函数，对单张图像进行 Grad-CAM 可视化、掩码生成与保存
def main(model, image_path, seg_path, mask_path, array_path):
    target_layers = [model.layer4]
    data_transform = transforms.Compose([transforms.Resize(300),
                                         transforms.ToTensor(),
                                         transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])

    # 读取图像
    assert os.path.exists(image_path), "file: '{}' dose not exist.".format(image_path)
    img = Image.open(image_path).convert('RGB')
    img_np = np.array(img, dtype=np.uint8)
    img_tensor = data_transform(img)
    input_tensor = torch.unsqueeze(img_tensor, dim=0).cuda()
    # 获取模型输出 logits，并进行阈值筛选，保留激活类的下标
    logit = model(input_tensor)  # [64, 1, 768]
    thresholded_predictions = 1 * (logit.detach().cpu().numpy() > thresholds)
    indices = np.where(thresholded_predictions[0] == 1)[0]

    # 创建 GradCAM 实例
    cam = GradCAM(model=model, target_layers=target_layers, use_cuda=False)
    # 初始化累加的 mask 图像（最终掩码）
    mask_arr_ass = np.zeros((300, 300, 3))
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))

    # 遍历所有预测为正的类别，依次生成 CAM 掩码
    for target_category in list(indices):
        grayscale_cam = cam(input_tensor=input_tensor, target_category=int(target_category))

        grayscale_cam = grayscale_cam[0, :]
        # 将 CAM 映射到热力图 + 原图叠加
        _, heatmap = show_cam_on_image(img_np.astype(dtype=np.float32) / 255.,
                                       grayscale_cam,
                                       use_rgb=True)
        # 对热力图进行阈值化得到二值 mask
        threshold = 0.6
        mask = cv2.threshold(heatmap, threshold, 1, cv2.THRESH_BINARY)[1]
        mask = cv2.dilate(mask, kernel)# 膨胀处理，扩大高响应区域
        mask = mask.astype(np.uint8) * 255
        mask_arr = np.asarray(mask)
        mask_arr_ass += mask_arr# 所有类别的掩码叠加
    # 将累加的 mask 取布尔化（非零视为有效区域）
    mask_arr_ass = np.any(mask_arr_ass, axis=2)
    # 保存掩码数组为 .npy 文件
    np.save(array_path, mask_arr_ass)
    mask = Image.fromarray((mask_arr_ass * 255).astype(np.uint8)).convert('L')
    mask.save(mask_path)
    img = Image.open(image_path)
    img = mask * np.asarray(img)
    img = Image.fromarray(img)
    img.save(seg_path)


if __name__ == '__main__':
    #image_list = glob.glob("../dataset/mimic_cxr/images300/*/*/*/*.jpg")
    image_list = glob.glob("E:\zb\dataset\medical_CT\images300\*.png")
    model = get_model()
    bar = tqdm.tqdm(image_list)
    for image_path in bar:
        seg_path = image_path.replace("images300", "resnet34_300/images300_seg")
        mask_path = image_path.replace("images300", "resnet34_300/images300_mask")
        array_path = image_path.replace("images300", "resnet34_300/images300_array").replace(".png", ".npy")

        if not os.path.exists(os.path.dirname(seg_path)):
            os.makedirs(os.path.dirname(seg_path))
            os.makedirs(os.path.dirname(mask_path))
            os.makedirs(os.path.dirname(array_path))
        if not os.path.exists(seg_path):
            main(model, image_path, seg_path, mask_path, array_path)

# 在 __main__ 部分添加调试代码
# if __name__ == '__main__':
#     # 输入路径验证
#     image_list = glob.glob("E:\zb\dataset\medical_CT\image\*.png")
#     print(f"找到 {len(image_list)} 个图像文件")
#
#     if not image_list:
#         raise FileNotFoundError("未找到任何.png文件！请检查路径：E:\\zb\\dataset\\medical_CT\\image")
#
#     # 模型验证
#     model = get_model()
#     print("模型加载完成，设备：", next(model.parameters()).device)
#
#     # 处理过程
#     bar = tqdm.tqdm(image_list)
#     for image_path in bar:
#         try:
#             # ...（原有路径处理逻辑）...
#             if not os.path.exists(seg_path):
#                 print(f"\n开始处理：{image_path}")  # 调试日志
#                 main(model, image_path, seg_path, mask_path, array_path)
#         except Exception as e:
#             print(f"处理失败：{image_path}\n错误：{str(e)}")
#             raise
