# Download Model Weights

## You can download the model weights from：

https://huggingface.co/ShenshenBu/EKAGen/blob/main/MIMIC_best_weight.pth



