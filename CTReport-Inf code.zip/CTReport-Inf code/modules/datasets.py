import json
import os

import torch
from PIL import Image
from torch.utils.data import Dataset
import numpy as np



class BaseDataset(Dataset):
    def __init__(self, args, tokenizer, split, transform=None):
        self.image_dir = args.image_dir         # 图像文件夹路径
        #消融实验 去掉ADM
        #self.mask_dir = args.mask_dir           # 掩码文件夹路径
        self.ann_path = args.ann_path           # 注释（JSON）路径
        self.max_seq_length = args.max_seq_length  # 最大报告长度
        self.split = split                           # 数据划分
        self.tokenizer = tokenizer                 # 用于文本编码的分词器
        self.transform = transform                  # 图像增强
        # 读取注释文件，按 split 划分提取样本
        self.ann = json.loads(open(self.ann_path, 'r',encoding='utf-8').read())
        self.examples = self.ann[self.split]
        # 预先把 report 转成 ids 和 mask  对每个样本预先进行报告编码和报告掩码生成
        for i in range(len(self.examples)):
            self.examples[i]['ids'] = tokenizer(self.examples[i]['report'])[:self.max_seq_length]
            self.examples[i]['mask'] = [1] * len(self.examples[i]['ids'])

    def __len__(self):
        return len(self.examples)


class IuxrayMultiImageDataset(BaseDataset):
    def __getitem__(self, idx):
        example = self.examples[idx]
        image_id = example['id']
        image_path = example['image_path']
        image_1 = Image.open(os.path.join(self.image_dir, image_path[0])).convert('RGB')
        #image_2 = Image.open(os.path.join(self.image_dir, image_path[1])).convert('RGB')
        if self.transform is not None:
            image_1 = self.transform(image_1)
            #image_2 = self.transform(image_2)
        #image = torch.stack((image_1, image_2), 0)
        image = torch.stack([image_1], dim=0)



        # ---------------------------
        image_folder = example['image_path']
        # 1. 加载图像（0.png 和 1.png）

        subfolder = image_folder[0]  # "image1001"
        # 拼出两张图像的完整路径
        img0 = Image.open(os.path.join(self.image_dir, image_path[0])).convert('RGB')
        img1 = Image.open(os.path.join(self.image_dir, image_path[1])).convert('RGB')

        # 图像增强
        if self.transform is not None:
            img0 = self.transform(img0)
            img1 = self.transform(img1)

        image = torch.stack([img0, img1], dim=0)  # [2, C, H, W]

        # ---------------------------
        # 2. 加载对应的两个 .npy 掩码（0.npy 和 1.npy）
        # ---------------------------
        # 读取 mask 的子目录
        rel_path = image_path[0]
        subfolder = os.path.dirname(rel_path)  # 结果 "image1001"
        mask_subdir = os.path.join(self.mask_dir, subfolder)
        mask0_path = os.path.join(mask_subdir, "0.npy")
        mask1_path = os.path.join(mask_subdir, "1.npy")

        # 加载掩码为 numpy 数组
        mask0_np = np.load(mask0_path)  # e.g. [H, W] 或者 [1, H, W]
        mask1_np = np.load(mask1_path)
        # 转为 torch.Tensor，并加上 channel 维度
        mask0 = torch.from_numpy(mask0_np).float()  # [H, W] 或 [1, H, W]
        mask1 = torch.from_numpy(mask1_np).float()

        if mask0.dim() == 2:
            mask0 = mask0.unsqueeze(0)  # -> [1, H, W]
        if mask1.dim() == 2:
            mask1 = mask1.unsqueeze(0)  # -> [1, H, W]

        # 最终把两张 mask stack 到 [2, 1, H, W]
        mask = torch.stack([mask0, mask1], dim=0)  # [2, 1, H, W]

        # ---------------------------

        report_ids = example['ids']
        report_masks = example['mask']
        seq_length = len(report_ids)
        sample = (image_id, image, mask ,report_ids, report_masks, seq_length)
        return sample


class MimiccxrSingleImageDataset(BaseDataset):
    def __getitem__(self, idx):
        example = self.examples[idx]
        image_id = example['id']
        image_path = example['image_path']
        # 如果 image_path 是列表，取第一个元素
        if isinstance(image_path, list):
            image_path = image_path[0]

        # 或者检查是否是字符串，如果不是则转换
        if not isinstance(image_path, str):
            image_path = str(image_path)
        # image = Image.open(os.path.join(self.image_dir, image_path[0])).convert('RGB')
        # image = Image.open(os.path.join(self.image_dir, image_path)).convert('RGB')
        full_image_path = os.path.join(self.image_dir, image_path)
        image = Image.open(full_image_path).convert('RGB')
        # image_id = os.path.join(self.image_dir, image_path[0])
        image_id = os.path.join(self.image_dir, image_path)
        if self.transform is not None:
            image = self.transform(image)
            # 2. 加载单视角对应的 .npy 掩码
           # mask_filename = os.path.splitext(image_path[0])[0] + "_mask.npy"  # "00123_mask.npy"
           # mask_filename = os.path.splitext(os.path.basename(image_path))[0] + "_mask.npy"

            # 消融实验 去掉ADM
    #   image_basename = os.path.splitext(os.path.basename(image_path))[0]  # "0"
    #   mask_dir_rel = os.path.dirname(image_path)  # "CT2199"
    #   mask_filename = image_basename + ".npy"  # "0.npy"
    #   mask_path = os.path.join(self.mask_dir, mask_dir_rel, mask_filename)

    #   mask_dir = os.path.dirname(image_path)
    #  # mask_path = os.path.join(self.mask_dir, mask_dir, mask_filename)
    #  # mask_path = os.path.join(self.mask_dir, image_id, mask_filename)
            # 读取 .npy

            #消融实验 去掉ADM
      # mask_np = np.load(mask_path)  # [H, W] or [1, H, W]
      # mask = torch.from_numpy(mask_np).float()
      # if mask.dim() == 2:
      #     mask = mask.unsqueeze(0)  # -> [1, H, W]

        report_ids = example['ids']
        report_masks = example['mask']
        seq_length = len(report_ids)

        #消融实验前
        #sample = (image_id, image, mask, report_ids, report_masks, seq_length)

        #消融实验 去掉ADM
        sample = (image_id, image, report_ids, report_masks, seq_length)
        return sample
