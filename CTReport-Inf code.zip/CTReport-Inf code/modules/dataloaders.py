import numpy as np
import torch
from torch.utils.data import DataLoader
from torchvision import transforms

from .datasets import IuxrayMultiImageDataset, MimiccxrSingleImageDataset


class R2DataLoader(DataLoader):
    def __init__(self, args, tokenizer, split, shuffle):
        # 初始化参数
        self.args = args
        self.dataset_name = args.dataset_name
        self.batch_size = args.batch_size
        self.shuffle = shuffle
        self.num_workers = args.num_workers
        self.tokenizer = tokenizer
        self.split = split

        # 根据数据划分设置图像预处理操作
        if split == 'train':
            self.transform = transforms.Compose([
                transforms.Resize(256),
                transforms.RandomCrop(224),
                transforms.RandomHorizontalFlip(),
                transforms.ToTensor(),
                transforms.Normalize((0.485, 0.456, 0.406),
                                     (0.229, 0.224, 0.225))])
        else:
            self.transform = transforms.Compose([
                transforms.Resize((224, 224)),
                transforms.ToTensor(),
                transforms.Normalize((0.485, 0.456, 0.406),
                                     (0.229, 0.224, 0.225))])

        # 根据数据集名称选择不同的数据集类
        if self.dataset_name == 'iu_xray':
            self.dataset = IuxrayMultiImageDataset(self.args, self.tokenizer, self.split, transform=self.transform)
        else:
            self.dataset = MimiccxrSingleImageDataset(self.args, self.tokenizer, self.split, transform=self.transform)

        # 初始化DataLoader参数
        self.init_kwargs = {
            'dataset': self.dataset,
            'batch_size': self.batch_size,
            'shuffle': self.shuffle,
            'collate_fn': self.collate_fn,
            'num_workers': self.num_workers
        }
        super().__init__(**self.init_kwargs)

    @staticmethod
    def collate_fn(data):
        data = [d for d in data if d is not None]
        if len(data) == 0:
            raise RuntimeError("collate_fn: batch contained only None samples")
        #image_id_batch, image_batch, report_ids_batch, report_masks_batch, seq_lengths_batch = zip(*data)
        #引入adm 解包数据，包括图像ID、图像张量、掩码、报告token ID、报告mask、报告长度
        #消融实验前代码
        #image_id_batch, image_batch, mask_batch,report_ids_batch, report_masks_batch, seq_lengths_batch = zip(*data)

        #消融实验 去掉ADM
        image_id_batch, image_batch,  report_ids_batch, report_masks_batch, seq_lengths_batch = zip(*data)

        # 将图像张量拼接成一个batch的张量
        image_batch = torch.stack(image_batch, 0)
        #引入adm 将掩码张量拼接成一个batch的张量

        #消融实验 去掉ADM
      #  mask_batch = torch.stack(mask_batch, 0)

        # 获取当前batch中最长的报告长度
        max_seq_length = max(seq_lengths_batch)

        # 初始化目标token数组（用于训练的目标序列）
        target_batch = np.zeros((len(report_ids_batch), max_seq_length), dtype=int)
        target_masks_batch = np.zeros((len(report_ids_batch), max_seq_length), dtype=int)

        # 填充每个样本的报告token序列
        for i, report_ids in enumerate(report_ids_batch):
            target_batch[i, :len(report_ids)] = report_ids

        # 填充每个样本的mask（标识有效token）
        for i, report_masks in enumerate(report_masks_batch):
            target_masks_batch[i, :len(report_masks)] = report_masks

        # 返回组成的一个batch数据，包含图像ID、图像、掩码、token序列、mask
        #消融实验 前 代码
       # return image_id_batch, image_batch, mask_batch,torch.LongTensor(target_batch), torch.FloatTensor(target_masks_batch)

        #消融实验 去掉ADM
        return image_id_batch, image_batch, torch.LongTensor(target_batch), torch.FloatTensor(target_masks_batch)
