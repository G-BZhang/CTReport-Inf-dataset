import logging
import os
from abc import abstractmethod

import torch
from numpy import inf


class BaseTrainer(object):
    """
       BaseTrainer 是一个抽象类，封装了训练过程中的公共逻辑：
         - 设备（CPU/GPU）准备
         - 日志记录
         - checkpoint 保存与恢复
         - early stopping
         - 训练轮次循环
       需要子类实现 _train_epoch 方法来定义每个 epoch 内的具体训练和验证流程。
       """
    def __init__(self, model, criterion, metric_ftns, optimizer, args, lr_scheduler):
        self.args = args

        # 配置日志格式：时间戳 - 日志级别 - 日志名 - 消息
        logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s -   %(message)s',
                            datefmt='%m/%d/%Y %H:%M:%S', level=logging.INFO)
        self.logger = logging.getLogger(__name__)

        # setup GPU device if available, move model into configured device
        # ===== 1. GPU/CPU 设备准备 =====
        # 根据 args.n_gpu 请求的 GPU 数量，决定实际使用 GPU 设备
        self.device, device_ids = self._prepare_device(args.n_gpu)
        # 将模型移动到 device
        self.model = model.to(self.device)
        # 如果启用了多卡训练，则包装成 DataParallel
        if len(device_ids) > 1:
            self.model = torch.nn.DataParallel(model, device_ids=device_ids)

        # ===== 2. 损失函数、指标、优化器、学习率调度器 =====
        self.criterion = criterion           # 计算损失的函数
        self.metric_ftns = metric_ftns       # 评估指标（例如 BLEU, ROUGE 等）
        self.optimizer = optimizer           # 优化器
        self.lr_scheduler = lr_scheduler     # 学习率调度策略

        # ===== 3. 训练相关参数 =====
        self.epochs = self.args.epochs                # 总训练轮数
        self.save_period = self.args.save_period      # 多久（多少 epoch）保存一次 checkpoint

        # 指定监控的模式和指标
        self.mnt_mode = args.monitor_mode
        self.mnt_metric = 'val_' + args.monitor_metric
        self.mnt_metric_test = 'test_' + args.monitor_metric
        assert self.mnt_mode in ['min', 'max']

        # 根据监控模式初始化最佳值（
        self.mnt_best = inf if self.mnt_mode == 'min' else -inf
        # early_stop：在验证集指标不再提升的耐心值（连续多少个 epoch 未提升后停止训练）
        self.early_stop = getattr(self.args, 'early_stop', inf)

        self.start_epoch = 1                      # 从哪个 epoch 开始训练
        self.checkpoint_dir = args.save_dir       # checkpoint 保存目录

        # 用于记录验证集和测试集的“最佳”日志信息
        self.best_recorder = {'val': {self.mnt_metric: self.mnt_best},
                              'test': {self.mnt_metric_test: self.mnt_best}}

        # 如果 checkpoint 目录不存在，则创建
        if not os.path.exists(self.checkpoint_dir):
            os.makedirs(self.checkpoint_dir)

        # 如果用户提供了 resume 参数，就从 checkpoint 恢复训练
        if args.resume is not None:
            self._resume_checkpoint(args.resume)


    @abstractmethod
    def _train_epoch(self, epoch):        #抽象方法：定义一个 epoch 内的训练和验证逻辑
        raise NotImplementedError

    def train(self):
        """
                训练过程核心循环：
                  1. 遍历每个 epoch，调用 _train_epoch
                  2. 记录并打印当前 epoch 的日志信息
                  3. 检查验证指标是否有提升，并执行 early stopping
                  4. 定期保存 checkpoint
                """
        not_improved_count = 0
        for epoch in range(self.start_epoch, self.epochs + 1):
            result = self._train_epoch(epoch)

            # save logged informations into log dict
            log = {'epoch': epoch}
            log.update(result)
            self._record_best(log)

            # print logged informations to the screen
            for key, value in log.items():
                self.logger.info('\t{:15s}: {}'.format(str(key), value))

            # evaluate model performance according to configured metric, save best checkpoint as model_best
            best = False
            if self.mnt_mode != 'off':
                try:
                    # check whether model performance improved or not, according to specified metric(mnt_metric)
                    improved = (self.mnt_mode == 'min' and log[self.mnt_metric] <= self.mnt_best) or \
                               (self.mnt_mode == 'max' and log[self.mnt_metric] >= self.mnt_best)
                except KeyError:
                    self.logger.warning(
                        "Warning: Metric '{}' is not found. " "Model performance monitoring is disabled.".format(
                            self.mnt_metric))
                    self.mnt_mode = 'off'
                    improved = False

                if improved:
                    self.mnt_best = log[self.mnt_metric]
                    not_improved_count = 0
                    best = True
                else:
                    not_improved_count += 1

                if not_improved_count > self.early_stop:
                    self.logger.info("Validation performance didn\'t improve for {} epochs. " "Training stops.".format(
                        self.early_stop))
                    break

            if epoch % self.save_period == 0:
                self._save_checkpoint(epoch, save_best=best)

    def _record_best(self, log):
        """
                更新内部记录器 best_recorder：
                  - best_recorder['val'] 保存验证集上监控指标的最佳值及对应 log
                  - best_recorder['test'] 保存测试集上监控指标的最佳值及对应 log
                """
        improved_val = (self.mnt_mode == 'min' and log[self.mnt_metric] <= self.best_recorder['val'][
            self.mnt_metric]) or \
                       (self.mnt_mode == 'max' and log[self.mnt_metric] >= self.best_recorder['val'][self.mnt_metric])
        if improved_val:
            self.best_recorder['val'].update(log)

        improved_test = (self.mnt_mode == 'min' and log[self.mnt_metric_test] <= self.best_recorder['test'][
            self.mnt_metric_test]) or \
                        (self.mnt_mode == 'max' and log[self.mnt_metric_test] >= self.best_recorder['test'][
                            self.mnt_metric_test])
        if improved_test:
            self.best_recorder['test'].update(log)

    def _print_best(self):
        """
                打印验证集和测试集上的最优指标。
                通常在训练结束后调用此函数查看最终最佳结果。
                """
        self.logger.info('Best results (w.r.t {}) in validation set:'.format(self.args.monitor_metric))
        for key, value in self.best_recorder['val'].items():
            self.logger.info('\t{:15s}: {}'.format(str(key), value))

        self.logger.info('Best results (w.r.t {}) in test set:'.format(self.args.monitor_metric))
        for key, value in self.best_recorder['test'].items():
            self.logger.info('\t{:15s}: {}'.format(str(key), value))

    def _prepare_device(self, n_gpu_use):
        """
                准备训练设备:
                  - 如果请求使用 GPU，但本机没有可用 GPU，则降级为 CPU 并发出警告。
                  - 如果请求使用的 GPU 数量超过可用数量，也发出警告并调整为最大可用数。
                返回:
                  - device: torch.device 对象（cuda:0 或 cpu）
                  - list_ids: 可用 GPU 的 id 列表
                """
        n_gpu = torch.cuda.device_count()
        if n_gpu_use > 0 and n_gpu == 0:
            self.logger.warning(
                "Warning: There\'s no GPU available on this machine," "training will be performed on CPU.")
            n_gpu_use = 0
        if n_gpu_use > n_gpu:
            self.logger.warning(
                "Warning: The number of GPU\'s configured to use is {}, but only {} are available " "on this machine.".format(
                    n_gpu_use, n_gpu))
            n_gpu_use = n_gpu
        device = torch.device('cuda:0' if n_gpu_use > 0 else 'cpu')
        list_ids = list(range(n_gpu_use))
        return device, list_ids

    def _save_checkpoint(self, epoch, save_best=False):
        """
                保存当前模型状态为 checkpoint，并在必要时另存一份“最佳模型”：
                  - state 包含：当前 epoch、模型参数、优化器状态、monitor_best
                  - checkpoint 文件命名为 current_checkpoint.pth
                  - 如果 save_best=True，则额外保存 model_best.pth
                """
        state = {
            'epoch': epoch,
            'state_dict': self.model.state_dict(),
            'optimizer': self.optimizer.state_dict(),
            'monitor_best': self.mnt_best
        }
        filename = os.path.join(self.checkpoint_dir, 'current_checkpoint.pth')
        torch.save(state, filename)
        self.logger.info("Saving checkpoint: {} ...".format(filename))
        if save_best:
            best_path = os.path.join(self.checkpoint_dir, 'model_best.pth')
            torch.save(state, best_path)
            self.logger.info("Saving current best: model_best.pth ...")

    def _resume_checkpoint(self, resume_path):
        """
                从指定的 checkpoint 恢复训练状态：
                  - 加载保存的 epoch、模型参数、优化器参数、monitor_best
                  - 设置 start_epoch 为 (checkpoint_epoch + 1)
                """
        resume_path = str(resume_path)
        self.logger.info("Loading checkpoint: {} ...".format(resume_path))
        checkpoint = torch.load(resume_path)
        self.start_epoch = checkpoint['epoch'] + 1
        self.mnt_best = checkpoint['monitor_best']
        self.model.load_state_dict(checkpoint['state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer'])

        self.logger.info("Checkpoint loaded. Resume training from epoch {}".format(self.start_epoch))


class Trainer(BaseTrainer):
    """
        Trainer 继承自 BaseTrainer，实现了具体的 _train_epoch 方法来：
          - 在一个 epoch 中对训练集进行前向、反向传播并记录损失
          - 在一个 epoch 结束后，对验证集和测试集进行评估并计算指标
          - 更新学习率调度器
        """
    def __init__(self, model, criterion, metric_ftns, optimizer, args, lr_scheduler, train_dataloader,
                 val_dataloader, test_dataloader):
        super(Trainer, self).__init__(model, criterion, metric_ftns, optimizer, args, lr_scheduler)
        self.train_dataloader = train_dataloader
        self.val_dataloader = val_dataloader
        self.test_dataloader = test_dataloader

    def _train_epoch(self, epoch):

        """
                执行单个 epoch 的训练和评估流程，返回一个包含以下 key 的 dict:
                  - 'train_loss': 训练集上的平均损失
                  - 'val_<metric>': 验证集上的评估指标（通过 metric_ftns 计算）
                  - 'test_<metric>': 测试集上的评估指标
                """
        # ------ 1. 训练阶段 ------
        self.logger.info('[{}/{}] Start to train in the training set.'.format(epoch, self.epochs))
        train_loss = 0
        self.model.train()
        #消融实验 去掉ADM 原代码：(images_id, images, mask, reports_ids, reports_masks)
        for batch_idx, (images_id, images, reports_ids, reports_masks) in enumerate(self.train_dataloader):

            images, reports_ids, reports_masks = images.to(self.device), reports_ids.to(self.device), \
                                                 reports_masks.to(self.device)
            # 前向传播：模型返回未归一化的分数或 loss 计算所需的输出
            output = self.model(images, reports_ids, mode='train')
            # 计算损失
            loss = self.criterion(output, reports_ids, reports_masks)
            train_loss += loss.item()
            # 反向传播与梯度更新
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
            # 每隔 log_period 步打印一次当前平均训练损失
            if batch_idx % self.args.log_period == 0:
                self.logger.info('[{}/{}] Step: {}/{}, Training Loss: {:.5f}.'
                                 .format(epoch, self.epochs, batch_idx, len(self.train_dataloader),
                                         train_loss / (batch_idx + 1)))

        # 记录训练集上的平均损失
        log = {'train_loss': train_loss / len(self.train_dataloader)}

        # ------ 2. 验证阶段 ------
        self.logger.info('[{}/{}] Start to evaluate in the validation set.'.format(epoch, self.epochs))
        self.model.eval()
        with torch.no_grad():
            val_gts, val_res = [], []
            # 消融实验 去掉ADM 原代码：(images_id, images, mask, reports_ids, reports_masks)
            for batch_idx, (images_id, images, reports_ids, reports_masks) in enumerate(self.val_dataloader):
                images, reports_ids, reports_masks = images.to(self.device), reports_ids.to(
                    self.device), reports_masks.to(self.device)

                output, _ = self.model(images, mode='sample')
                reports = self.model.tokenizer.decode_batch(output.cpu().numpy())
                ground_truths = self.model.tokenizer.decode_batch(reports_ids[:, 1:].cpu().numpy())
                val_res.extend(reports)
                val_gts.extend(ground_truths)

            # 计算验证集上的指标（例如 BLEU、ROUGE 等），格式是 dict
            val_met = self.metric_ftns({i: [gt] for i, gt in enumerate(val_gts)},
                                       {i: [re] for i, re in enumerate(val_res)})
            log.update(**{'val_' + k: v for k, v in val_met.items()})

        # ------ 3. 测试阶段 ------
        self.logger.info('[{}/{}] Start to evaluate in the test set.'.format(epoch, self.epochs))
        self.model.eval()
        with torch.no_grad():
            test_gts, test_res = [], []
            #消融实验 去掉ADM 原代码：(images_id, images, mask, reports_ids, reports_masks)
            for batch_idx, (images_id, images,reports_ids, reports_masks) in enumerate(self.test_dataloader):
                images, reports_ids, reports_masks = images.to(self.device), reports_ids.to(
                    self.device), reports_masks.to(self.device)
                output, _ = self.model(images, mode='sample')
                reports = self.model.tokenizer.decode_batch(output.cpu().numpy())
                ground_truths = self.model.tokenizer.decode_batch(reports_ids[:, 1:].cpu().numpy())
                test_res.extend(reports)
                test_gts.extend(ground_truths)

            test_met = self.metric_ftns({i: [gt] for i, gt in enumerate(test_gts)},
                                        {i: [re] for i, re in enumerate(test_res)})
            log.update(**{'test_' + k: v for k, v in test_met.items()})

        # ------ 4. 更新学习率调度器 ------
        self.lr_scheduler.step()

        return log
