import numpy as np
import torch
import torch.nn as nn

from modules.base_cmn import BaseCMN                       # 编码器-解码器模型（跨模态记忆网络）
from modules.visual_extractor import VisualExtractor       # 图像特征提取器

#基础跨模态记忆网络模型定义
class BaseCMNModel(nn.Module):
    def __init__(self, args, tokenizer):
        super(BaseCMNModel, self).__init__()
        self.args = args
        self.tokenizer = tokenizer
#消融时0 完整1
        self.args.use_cmm = 0

        self.visual_extractor = VisualExtractor(args)        #提取输入图像的视觉特征
        self.encoder_decoder = BaseCMN(args, tokenizer)      #编码器-解码器结构，处理视觉与语言之间的跨模态建模
        if args.dataset_name == 'iu_xray':
            self.forward = self.forward_iu_xray
        else:
            self.forward = self.forward_mimic_cxr

    def __str__(self):
        model_parameters = filter(lambda p: p.requires_grad, self.parameters())
        params = sum([np.prod(p.size()) for p in model_parameters])
        return super().__str__() + '\nTrainable parameters: {}'.format(params)

    def forward_iu_xray(self, images, targets=None, mode='train', update_opts={}):
        # att_feats_0, fc_feats_0 = self.visual_extractor(images[:, 0])
        # att_feats_1, fc_feats_1 = self.visual_extractor(images[:, 1])

        # 检查输入是否为单视角（形状可能是 [B, C, H, W] 或 [B, 1, C, H, W]）
        if images.dim() == 4:  # 单张图像 [B, C, H, W]
            images = images.unsqueeze(1)  # 转为 [B, 1, C, H, W]

        # 提取第一个视角特征
        att_feats_0, fc_feats_0 = self.visual_extractor(images[:, 0])

        # 双视角输入
        if images.size(1) == 1:  # 单视角
            att_feats_1, fc_feats_1 = att_feats_0, fc_feats_0
        else:  # 双视角
            att_feats_1, fc_feats_1 = self.visual_extractor(images[:, 1])

        fc_feats = torch.cat((fc_feats_0, fc_feats_1), dim=1)
        att_feats = torch.cat((att_feats_0, att_feats_1), dim=1)
        if mode == 'train':
            output = self.encoder_decoder(fc_feats, att_feats, targets, mode='forward')
            return output
        elif mode == 'sample':
            output, output_probs = self.encoder_decoder(fc_feats, att_feats, mode='sample', update_opts=update_opts)
            return output, output_probs
        else:
            raise ValueError

    def forward_mimic_cxr(self, images, targets=None, mode='train', update_opts={}):
        att_feats, fc_feats = self.visual_extractor(images)
        if mode == 'train':
            output = self.encoder_decoder(fc_feats, att_feats, targets, mode='forward')
            return output
        elif mode == 'sample':
            output, output_probs = self.encoder_decoder(fc_feats, att_feats, mode='sample', update_opts=update_opts)
            return output, output_probs
        else:
            raise ValueError
